<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">All contacts </div>

                    <div class="card-body">
                        <?php if(session('status')): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>

                        <div>

                            <?php if(session()->has('successDelete')): ?>
                                <div class="col-10">
                                    <div class="alert alert-success mt-2">
                                        <ul>
                                            <li><?php echo e(session()->get('successDelete')); ?></li>
                                        </ul>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>

                        <a class="btn btn-success mb-3 text-white" href="<?php echo e(route('contacts.create')); ?>">
                            New contact
                        </a>
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Name</th>
                                    <th scope="col">Contact</th>
                                    <th scope="col">Email address</th>
                                    <th scope="col">Edit</th>
                                    <th scope="col">delete</th>
                                </tr>
                            </thead>
                            <tbody>

                                <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th scope="row"><?php echo e($contact -> id); ?></th>
                                        <td><?php echo e($contact ->name); ?></td>
                                        <td><?php echo e($contact ->contact); ?></td>
                                        <td><?php echo e($contact ->email); ?></td>
                                        <td> <a class="btn btn-warning" href="<?php echo e(route('contacts.show',['contact' => $contact ->id])); ?>">Edit</a> </td>
                                        <td>
                                            <form onsubmit="return confirm('Are you sure you want to delete this contact?')" method="post"  action="<?php echo e(route('contacts.destroy',['contact' => $contact ->id])); ?>" >
                                                <?php echo e(csrf_field()); ?>

                                                <?php echo e(method_field('DELETE')); ?>

                                                <button class="btn btn-danger">Delete</button>
                                            </form>

                                        </td>

                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Marcelo\Desktop\alfa\ContactManagement\resources\views/contact/index.blade.php ENDPATH**/ ?>