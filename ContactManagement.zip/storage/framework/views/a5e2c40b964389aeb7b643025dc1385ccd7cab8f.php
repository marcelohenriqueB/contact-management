

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header"> Create contact</div>
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger mt-2">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>


                    <div class="card-body">
                        <div class="row justify-content-center">
                            <form action="<?php echo e(route('contacts.store')); ?>" method="post" class="col-10">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label for="name">Name</label>
                                    <input id="name" type="text" class="form-control" name="name" value="<?php echo e(old('name')); ?>" >
                                </div>
                                <div class="form-group">
                                    <label for="email">E-mail</label>
                                    <input id="email" type="text" class="form-control" name="email" value="<?php echo e(old('email')); ?>">
                                </div>

                                <div class="form-group">
                                    <label for="contact">contact</label>
                                    <input id="contact" type="text" class="form-control" name="contact" value="<?php echo e(old('contact')); ?>" maxlength="9">
                                </div>
                                <button class="btn btn-success text-white mt-2" type="submit">
                                    Create contact
                                </button>

                            </form>

                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Marcelo\Desktop\alfa\ContactManagement\resources\views/contact/create.blade.php ENDPATH**/ ?>