<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">Edit contact #<?php echo e($contact ->id); ?></div>





                    <div class="card-body">
                        <div class="row justify-content-center">
                            <?php if($errors->any()): ?>
                                <div class="col-10">
                                    <div class="alert alert-danger">
                                        <ul>
                                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><?php echo e($error); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </div>
                                </div>
                            <?php endif; ?>
                            <?php if(session()->has('success')): ?>
                                <div class="col-10">
                                    <div class="alert alert-success mt-2">
                                        <ul>
                                            <li><?php echo e(session()->get('success')); ?></li>
                                        </ul>
                                    </div>
                                </div>

                            <?php endif; ?>

                            <div class="col-10 text-end">
                                <form method="post"  action="<?php echo e(route('contacts.destroy',['contact' => $contact ->id])); ?>" onsubmit="return confirm('Are you sure you want to delete this contact?');">
                                    <?php echo e(csrf_field()); ?>

                                    <?php echo e(method_field('DELETE')); ?>

                                    <button class="btn btn-danger text-white btn-sm mt-2"  type="submit">
                                        Delete contact
                                    </button>
                                </form>
                            </div>

                            <form action="<?php echo e(route('contacts.update',['contact' => $contact ->id])); ?>" method="post" class="col-10">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="_method" value="PUT">
                                <div class="form-group">
                                    <label for="name">Name</label>
                                    <input id="name" type="text" class="form-control" name="name" value="<?php echo e($contact ->name); ?>" >
                                </div>
                                <div class="form-group">
                                    <label for="email">E-mail</label>
                                    <input id="email" type="text" class="form-control" name="email" value="<?php echo e($contact ->email); ?>">
                                </div>

                                <div class="form-group">
                                    <label for="contact">contact</label>
                                    <input id="contact" type="text" class="form-control" name="contact" value="<?php echo e($contact ->contact); ?>" maxlength="9">
                                </div>
                                <button class="btn btn-warning  mt-3" type="submit">
                                    Edit contact
                                </button>

                            </form>

                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Marcelo\Desktop\alfa\ContactManagement\resources\views/contact/show.blade.php ENDPATH**/ ?>